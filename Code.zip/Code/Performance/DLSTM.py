from keras.models import Sequential
model = Sequential()
import nltk
from nltk.corpus import stopwords
import numpy as np
from keras.models import Sequential
from keras.layers import Dense, LSTM
from keras.layers import Dropout
from sklearn.model_selection import train_test_split
from Performance import FGSDO
from keras.optimizers import Adam as Opt


def regenerate_text(text):
  tokens = nltk.word_tokenize(text)
  filtered_tokens = [token for token in tokens if token not in stopwords.words('english')]
  lemmatizer = nltk.WordNetLemmatizer()
  lemmatized_tokens = [lemmatizer.lemmatize(token) for token in filtered_tokens]
  new_text = ' '.join(lemmatized_tokens)
  return new_text


def classify(IS, label, tr_per, ACC1, SEN1, SPE1, epochs, f_data, Data):

    IS = IS[:len(f_data)]
    ACC, SEN, SPE = [], [], []

    for i in range(len(IS)):
        Is = IS[i]
        l = np.resize(label[i], (len(Is)))
        SEN1 = f_data[i]
        w = Data[i]
        w = w[:len(Is)]
        data = Is + w
        x_train, x_test, y_train, y_test = train_test_split(data, l, train_size=tr_per)

        n_cls = len(np.unique(l))

        # Reshape the data into 3-D array
        # Initialising the RNN
        model = Sequential()

        model.add(LSTM(units=50, return_sequences=True, input_shape=(len(Is), 1)))
        model.add(Dropout(0.2))

        # Adding a second LSTM layer and Dropout layer
        model.add(LSTM(units=50, return_sequences=True))
        model.add(Dropout(0.2))

        # Adding a third LSTM layer and Dropout layer
        model.add(LSTM(units=50, return_sequences=True))
        model.add(Dropout(0.2))

        # Adding a fourth LSTM layer and Dropout layer
        model.add(LSTM(units=50))
        model.add(Dropout(0.2))

        # Adding the output layer
        # For Full connection layer we use dense
        # As the output is 1D so we use unit=1
        model.add(Dense(units=n_cls))
        init_weight = model.get_weights()
        model.set_weights(np.array(init_weight, dtype=object))

        # compile and fit the model on 30 epochs
        model.compile(optimizer=Opt(learning_rate=FGSDO.golden_search(20)), loss='mean_squared_error')
        x_train1 = np.resize(x_train, (x_train.shape[0], len(Is), 1)).astype("int")
        y_train1 = np.resize(y_train, (y_train.shape[0], 10)).astype("int")
        model.fit(x_train1, y_train1, epochs=epochs, batch_size=32, verbose=0)
        # model.summary()
        x_test = abs(np.resize(x_test, (x_test.shape[0], len(Is), 1)).astype("int"))
        # check predicted values
        Predict = model.predict(x_test)
        Predict = np.round(Predict).astype("int")

        # Removal of fake word and review regeneration
        print(".............Original Sentence.............\n", SEN1[0])
        fake = []
        for i in range(len(Predict)):
            SENt = []
            if Predict[i] == 1:
                SENt1 = SEN1[0]
                SEN11 = SENt1.split(" ")
                if len(SEN11) == i or len(SEN11) < i:break
                SEN11 = " ".join(SEN11)
                SENt.append(SEN11)
                break
        if SENt == [] or fake == []:
            print(".........This phrase contains no fake words.......")
        else:
            print(" -------- Detected Fake Word ---------\n", fake[0])
            new_SEN = regenerate_text(SENt[0])
            print(".............Generated Sentence.............\n", new_SEN)

        uni_cls = np.unique(y_test)
        tp, tn, fn, fp = 0, 0, 0, 0
        for i1 in range(len(uni_cls)):
            c = uni_cls[i1]
            for i in range(len(y_test)):
                if y_test[i] == c and Predict[i] == c:
                    tp = tp + 1
                if y_test[i] != c and Predict[i] != c:
                    tn = tn + 1
                if y_test[i] == c and Predict[i] != c:
                    fn = fn + 1
                if y_test[i] != c and Predict[i] == c:
                    fp = fp + 1
        ACC1 = (tp + tn) / (tn + tp + fn + fp)  # Accuracy
        SEN1 = tp / (tp + fn)  # Sensitivity
        SPE1 = tn / (tn + fp)  # Specificity
        ACC.append(ACC1)
        SEN.append(SEN1)
        SPE.append(SPE1)
    ACC1.append(np.mean(ACC))
    SEN1.append(np.mean(SEN))
    SPE1.append(np.mean(SPE))

    return ACC1, SEN1, SPE1
