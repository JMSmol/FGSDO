import numpy as np
from scipy.spatial import distance as dist
import copy


def golden_search(ps):
    dims = 10
    num_gold = ps
    nturns = 100
    lower_bound = 70
    influence_factor = 30
    max_jitter = .2

    def fitness_function(xy_tuple):
        x = xy_tuple[0]/2
        y = xy_tuple[1]/2
        return np.sin(x**3 + (y-5)**3) + np.cos((y-5)**2) * 10 + np.cos(x*2) * 12 * (y-5)

    def starting_points():
        return np.random.rand(num_gold, 2) * 10
    
    def get_score(pop):
        temp = [(fitness_function(tup)) for tup in pop]
        normal = [x + lower_bound for x in temp]
        return [x / influence_factor for x in normal]

    # This returns a matrix with the distances between each worm calculated if the
    # worm in the row is influenced by the worm in the column, else 0
    def influence_matrix(pop, score):
        graph = np.array([np.zeros(num_gold)] * num_gold)
    
        for i in range(num_gold):
            for j in range(num_gold):
                if i == j:
                    graph[i][j] = 0
                elif dist.euclidean(pop[i], pop[j]) <= score[j]:
                    graph[i][j] = dist.euclidean(pop[i], pop[j])
                else:
                    continue
        return graph
    
    def next_turn(pop, score, im):
        n_turn = copy.deepcopy(pop)
    
        # X and Y movement is determined by the ratio of distance between worms and
        # the radius of the influencing worm
        # This ensures that closer worms will have more influence than further worms
        # with the same pull, and at the same time worms with large influences will
        # have more pull than other worms of the same distance
        for i in range(num_gold):
            x_move = 0
            y_move = 0
            Sti = score[0]
            A = score[0]
            Pp = pop[0]
            B = pop[0]

            for j in range(num_gold):
                percent_move = 1 - (im[i][j] / score[j]) if im[i][j] != 0 else 0
                x_move += (pop[j][0] - pop[i][0]) * percent_move / 10 if score[i] < score[j] else 0
                y_move += (pop[j][1] - pop[i][1]) * percent_move / 10 if score[i] < score[j] else 0
            jitter_x = max_jitter * np.random.rand() * np.random.randint(-1, 2)

            # INCLUDE DOX OPTIMIZATION
            Oi = ((B * Sti) - (Pp * (1 - (B*A)))) / (B-1)

            jitter_y = max_jitter * np.random.rand() * np.random.randint(-1, 2) + np.mean(Oi)
            n_turn[i][0] += x_move + jitter_x
            n_turn[i][1] += y_move + jitter_y
        
            n_turn[i][0] = keep_in_bounds(n_turn[i][0], dims)
            n_turn[i][1] = keep_in_bounds(n_turn[i][1], dims)
        
        return n_turn
        
    def keep_in_bounds(x, dims):
        if x < 0:
            return 0
        elif x > dims:
            return dims
        else:
            return x
    num_gold = 20
    # START #
    pop = starting_points()
    for each in range(nturns):
        score = get_score(pop)
        im = influence_matrix(pop, score)
        pop = copy.deepcopy(next_turn(pop, score, im))
    return np.mean(pop)


