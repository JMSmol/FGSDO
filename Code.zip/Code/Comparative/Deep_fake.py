from keras.src.models import Sequential
from keras.src.layers import Dense
from sklearn.model_selection import train_test_split
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import numpy as np
import time


def detect(Data, Label, tr, ACC, SEN, SPE, TIME):
    s_time = time.time()

    x_train, x_test, y_train, y_test = train_test_split(Data, Label, train_size=tr)

    n_cls = len(np.unique(Label))
    model = Sequential()
    model.add(Dense(12, input_shape=(x_train.shape[1], 1), activation='relu'))
    model.add(Dense(8, activation='relu'))
    model.add(Dense(n_cls, activation='sigmoid'))

    # compile the model
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

    x_train1 = np.resize(x_train, (len(x_train), x_train.shape[1], 1))
    x_test1 = np.resize(x_test, (len(x_test), x_train.shape[1], 1))
    y_train1 = np.resize(y_train, (len(y_train), n_cls))
    model.fit(x_train1, y_train1, epochs=10, verbose=0)
    Predict = model.predict(x_test1)
    e_time = time.time()

    uni_cls = np.unique(y_test)
    tp, tn, fn, fp = 0, 0, 0, 0
    for i1 in range(len(uni_cls)):
        c = uni_cls[i1]
        for i in range(len(y_test)):
            if y_test[i] == c and Predict[i] == c:
                tp = tp + 1
            if y_test[i] != c and Predict[i] != c:
                tn = tn + 1
            if y_test[i] == c and Predict[i] != c:
                fn = fn + 1
            if y_test[i] != c and Predict[i] == c:
                fp = fp + 1
    acc = (tp + tn) / (tn + tp + fn + fp)  # accuracy
    sen = tp / (tp + fn)  # sensitivity
    spe = tn / (tn + fp)  # specificity
    t = e_time - s_time
    ACC.append(acc)
    SEN.append(sen)
    SPE.append(spe)
    TIME.append(t)

    return ACC, SEN, SPE, TIME
