import numpy as np
from sklearn.model_selection import train_test_split
from keras.src.layers import LSTM, Activation, Dense, Dropout, Embedding
from keras.src.models import Sequential
from keras.src.layers import Conv1D, MaxPooling1D
import DOX
from keras.src.optimizers import Adam as Opt
import time


def detect(Data, Label, tr, ACC, SEN, SPE, TIME):
    s_time = time.time()
    x1 = Data
    x2 = Label
    x_train, x_test, y_train, y_test = train_test_split(x1, x2, train_size=tr)

    max_features = 20000
    maxlen = 50
    embedding_size = 100

    # Convolution
    kernel_size = 5
    filters = 64
    pool_size = 4

    # LSTM
    lstm_output_size = 70
    # Training
    batch_size = 32
    epochs = 10

    model = Sequential()
    model.add(Embedding(max_features, embedding_size, input_length=maxlen))
    model.add(Dropout(0.25))
    model.add(Conv1D(filters, kernel_size, padding='valid', activation='leaky_relu', strides=2))
    model.add(MaxPooling1D(pool_size=pool_size))
    model.add(LSTM(lstm_output_size))
    model.add(Dense(1))
    model.add(Activation('softmax'))
    model.compile(loss='binary_crossentropy', optimizer=Opt(learning_rate=(DOX.Dingo_optimizer(10))),
                  metrics=['accuracy'])

    # model.summary()
    X_train = abs(np.resize(x_train, (len(x_train), maxlen)))
    X_test = abs(np.resize(x_test, (len(x_test), maxlen)))
    model.fit(X_train, y_train, batch_size=batch_size, epochs=epochs, verbose=0)
    Predict = model.predict(X_test)
    e_time = time.time()

    tp, tn, fn, fp = 0, 0, 0, 0
    uni_cls = np.unique(y_test)
    for i1 in range(len(uni_cls)):
        c = uni_cls[i1]
        for i in range(len(y_test)):
            if y_test[i] == c and Predict[i] == c:
                tp = tp + 1
            if y_test[i] != c and Predict[i] != c:
                tn = tn + 1
            if y_test[i] == c and Predict[i] != c:
                fn = fn + 1
            if y_test[i] != c and Predict[i] == c:
                fp = fp + 1
    acc = (tp + tn) / (tn + tp + fn + fp)  # accuracy
    sen = tp / (tp + fn)  # sensitivity
    spe = tn / (tn + fp)  # specificity
    t = e_time - s_time
    ACC.append(acc)
    SEN.append(sen)
    SPE.append(spe)
    TIME.append(t)

    return ACC, SEN, SPE, TIME



