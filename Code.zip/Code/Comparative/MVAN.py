from keras.src.models import Sequential
from keras.src.layers import Conv2D
from keras.src.layers import MaxPooling2D
from keras.src.layers import Flatten
from keras.src.layers import Dense
import numpy as np
from sklearn.model_selection import train_test_split
import time


def detect(Data, Label, tr, ACC, SEN, SPE, TIME):
    s_time = time.time()

    x_train, x_test, y_train, y_test = train_test_split(Data, Label, train_size=tr)

    n_cls = len(np.unique(Label))

    model = Sequential()
    model.add(Conv2D(32, (3, 3), input_shape=(x_train.shape[1], 10, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    # Adding a second convolutional layer
    model.add(Conv2D(30, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    # Step 3 - Flattening
    model.add(Flatten())
    # Step 4 - Full connection
    model.add(Dense(units=50, activation='relu'))
    model.add(Dense(units=Label, activation='sigmoid'))
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    x_test1 = abs(np.resize(x_test, (len(x_test), x_train.shape[1], 10, 3)))

    x_train1 = np.resize(x_train, (len(x_train), x_train.shape[1], 10, 3))
    y_train1 = np.resize(x_train, (len(y_train), n_cls))
    model.fit(x_train1, y_train1, batch_size=32, epochs=5, verbose=0)
    Predict = model.predict(x_test1)
    e_time = time.time()

    uni_cls = np.unique(y_test)
    tp, tn, fn, fp = 0, 0, 0, 0
    for i1 in range(len(uni_cls)):
        c = uni_cls[i1]
        for i in range(len(y_test)):
            if y_test[i] == c and Predict[i] == c:
                tp = tp + 1
            if y_test[i] != c and Predict[i] != c:
                tn = tn + 1
            if y_test[i] == c and Predict[i] != c:
                fn = fn + 1
            if y_test[i] != c and Predict[i] == c:
                fp = fp + 1
    acc = (tp + tn) / (tn + tp + fn + fp)  # accuracy
    sen = tp / (tp + fn)  # sensitivity
    spe = tn / (tn + fp)  # specificity
    t = e_time - s_time
    ACC.append(acc)
    SEN.append(sen)
    SPE.append(spe)
    TIME.append(t)

    return ACC, SEN, SPE, TIME

