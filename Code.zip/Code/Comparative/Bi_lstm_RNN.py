from keras.src.models import Sequential
import tensorflow as tf
model = Sequential()
import numpy as np
from sklearn.model_selection import train_test_split
import time


def detect(Data, Label, tr, ACC, SEN, SPE, TIME):
    s_time = time.time()

    x_train, x_test, y_train, y_test = train_test_split(Data, Label, train_size=tr)

    n_clas = len(np.unique(Label))
    model = tf.keras.models.Sequential()
    model.add(tf.keras.layers.Dense(units=6, activation="relu"))
    model.add(tf.keras.layers.Dense(units=n_clas, activation="sigmoid"))
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=['accuracy'])

    x_train1 = np.resize(x_train, (len(x_train), x_train.shape[1]))
    y_train1 = np.resize(x_train, (len(y_train), n_clas))
    x_test1 = np.resize(x_test, (len(x_test), x_test.shape[1]))
    model.fit(x_train1, y_train1, batch_size=32, epochs=10, verbose=0)
    Predict = model.predict(x_test1)
    e_time = time.time()

    uni_cls = np.unique(y_test)
    tp, tn, fn, fp = 0, 0, 0, 0
    for i1 in range(len(uni_cls)):
        c = uni_cls[i1]
        for i in range(len(y_test)):
            if y_test[i] == c and Predict[i] == c:
                tp = tp + 1
            if y_test[i] != c and Predict[i] != c:
                tn = tn + 1
            if y_test[i] == c and Predict[i] != c:
                fn = fn + 1
            if y_test[i] != c and Predict[i] == c:
                fp = fp + 1
    acc = (tp + tn) / (tn + tp + fn + fp)   # accuracy
    sen = tp / (tp + fn)                    # sensitivity
    spe = tn / (tn + fp)                    # specificity
    t = e_time - s_time
    ACC.append(acc)
    SEN.append(sen)
    SPE.append(spe)
    TIME.append(t)

    return ACC, SEN, SPE, TIME
