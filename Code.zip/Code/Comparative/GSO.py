import random
import numpy
import math
import numpy as np


def GSA(PopSize):
    def Fit(soln):  # creating function for fitness
        S = []
        for i in range(len(soln)):
            s = 0
            for j in range(len(soln[i])):
                s += soln[i][j] * random.random()
                f = 1 / s
                S.append(f)
        return S

    def solution(N, M): # generating solution
        data = []
        for i in range(N):  # N rows, M columns
            tem = []
            for j in range(M):
                tem.append(random.random())  # random values
            data.append(tem)
        return data

    def massCalculation(fit, PopSize, M): #mass calculation
        Fmax = max(fit)
        Fmin = min(fit)
        Fsum = sum(fit)
        Fmean = Fsum / len(fit)

        if Fmax == Fmin:
            M = numpy.ones(PopSize)
        else:
            best = Fmin
            worst = Fmax

            for p in range(0, PopSize):
                M[p] = (fit[p] - worst) / (best - worst)

        Msum = sum(M)
        for q in range(0, PopSize):
            M[q] = M[q] / Msum

        return M

    def gConstant(l, iters): #gravitational constant
        alfa = 20
        G0 = 100
        Gimd = numpy.exp(-alfa * float(l) / iters)
        G = G0 * Gimd
        return G

    def gField(PopSize, dim, pos, M, l, iters, G, ElitistCheck, Rpower): # gravitational field
        final_per = 2
        if ElitistCheck == 1:
            kbest = final_per + (1 - l / iters) * (100 - final_per)
            kbest = round(PopSize * kbest / 100)
        else:
            kbest = PopSize

        kbest = int(kbest)
        ds = sorted(range(len(M)), key=lambda k: M[k], reverse=True)

        Force = numpy.zeros((PopSize, dim))
        # Force = Force.astype(int)

        for r in range(0, PopSize):
            for ii in range(0, kbest):
                z = ds[ii]
                R = 0
                if z != r:
                    x = pos[r, :]
                    y = pos[z, :]
                    esum = 0
                    imval = 0
                    for t in range(0, dim):
                        imval = ((x[t] - y[t]) ** 2)
                        esum = esum + imval

                    R = math.sqrt(esum)

                    for k in range(0, dim):
                        randnum = random.random()
                        Force[r, k] = Force[r, k] + randnum * (M[z]) * (
                                (pos[z, k] - pos[r, k]) / (R ** Rpower + numpy.finfo(float).eps))

        acc = numpy.zeros((PopSize, dim))
        for x in range(0, PopSize):
            for y in range(0, dim):
                acc[x, y] = Force[x, y] * G
        return acc

    def move(PopSize, dim, pos, vel, acc): # velocity and position
        for i in range(0, PopSize):
            for j in range(0, dim):
                r1 = random.random()
                vel[i, j] = r1 * vel[i, j] + acc[i, j]
                pos[i, j] = pos[i, j] + vel[i, j]

        return pos, vel

    # GSA parameters
    ElitistCheck = 1
    Rpower = 1
    l, u = 0, 1
    lb = 1
    ub = 10
    dim = 10
    iters = 10

    # Initialization
    vel = numpy.zeros((PopSize, dim))
    fit = numpy.zeros(PopSize)
    M = numpy.zeros(PopSize)
    gBest = numpy.zeros(dim)
    gBestScore = float("inf")

    pos = numpy.asarray(solution(PopSize, dim))

    convergence_curve = numpy.zeros(iters)

    t = 0
    # Loop begins
    while (t < iters):
        for i in range(0, PopSize):
            l1 = [None] * dim
            l1 = numpy.clip(pos[i, :], lb, ub)
            pos[i, :] = l1

            fitness = []
            soln = numpy.array(Fit(pos))
            fitness = soln[i]
            fit[i] = fitness

            if (gBestScore > fitness):
                gBestScore = fitness
                gBest = l1

        M = massCalculation(fit, PopSize, M)  # Calculating Mass

        G = gConstant(l, iters)  # Calculating Gravitational Constant

        acc = gField(PopSize, dim, pos, M, l, iters, G, ElitistCheck, Rpower)  # Calculating Gfield

        pos, vel = move(PopSize, dim, pos, vel, acc)  # Calculating Position

        convergence_curve[l] = gBestScore

    best = numpy.argmin(gBestScore)
    return np.mean(best)

