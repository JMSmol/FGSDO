import numpy as np


def data_concat1():
    # True news data
    Bert_t = np.load(".../Dataset1_Bert_vec.npy")
    Word2vec_t = np.load(".../Dataset1_Word_vec.npy")
    Vec_t = np.concatenate((Bert_t, Word2vec_t), axis=1)

    # Fake news data
    Bert_f = np.load(".../Dataset1_Bert_vec1.npy")
    Word2vec_f = np.load(".../Dataset1_Word_vec1.npy")
    Vec_f = np.concatenate((Bert_f, Word2vec_f), axis=1)

    Vector = np.concatenate((Vec_t, Vec_f), axis=0)
    # np.save(".../Dataset1_Vector.npy", Vector)

    Label = []
    for i in range(len(Bert_t)):
        Label.append(0)
    for i in range(len(Bert_f)):
        Label.append(1)
    # np.save(".../Dataset1_Label.npy", Label)


def data_concat2():
    # True news data
    Bert_t = np.load(".../Dataset2_Bert_vec.npy")
    Word2vec_t = np.load(".../Dataset2_Word_vec.npy")
    Vec_t = np.concatenate((Bert_t, Word2vec_t), axis=1)

    # Fake news data
    Bert_f = np.load(".../Dataset2_Bert_vec1.npy")
    Word2vec_f = np.load(".../Dataset2_Word_vec1.npy")
    Vec_f = np.concatenate((Bert_f, Word2vec_f), axis=1)

    Vector = np.concatenate((Vec_t, Vec_f), axis=0)
    # np.save(".../Dataset2_Vector.npy", Vector)

    Label = []
    for i in range(len(Bert_t)):
        Label.append(0)
    for i in range(len(Bert_f)):
        Label.append(1)
    # np.save(".../Dataset2_Label.npy", Label)

