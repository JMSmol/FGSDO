import pandas as pd
import numpy as np
import nltk
nltk.download('sentiwordnet')
from nltk.corpus import sentiwordnet as swn
from nltk.corpus import stopwords


def noun(text):
    sentences = nltk.sent_tokenize(text)
    w, ww = [], []
    for sentence in sentences:
        words = nltk.word_tokenize(sentence)
        words = [word for word in words if word not in set(stopwords.words('english'))]
        tagged = nltk.pos_tag(words)
        for (word, tag) in tagged:
            if tag == 'NNP':  # If the word is a proper noun
                w.append(word)
            if tag == 'VB':
                ww.append(word)
            if tag == 'VBG':
                ww.append(word)
    return w, ww


def IM_feat1(Pred):
    file = np.array(pd.read_csv("...\Dataset\\true news.csv",
                       encoding='windows-1252', header=0, on_bad_lines="skip"))
    file = file[:, 1]
    file1 = np.array(pd.read_excel("...\Dataset\\Steni Jeyan.xls", header=None))
    file1 = file1[:, 1]
    Data = np.concatenate((file, file1), axis=0)

    F, p_D = [], []
    for i in range(len(Pred)):
        if Pred[i] == 1:
            d = Data[i]
            p_D.append([d])
            p_words, v_words = noun(d)
            d1 = d.replace("-", "").replace("(", "").replace(")", "").replace(",", "").replace('\x19', "")
            d2 = d1.split(" ")
            digits = "0123456789"
            ff = []
            for j in range(len(d2)):
                if d2[j] in digits:
                    ff.append(1)
                elif d2[j] in p_words:
                    ff.append(0.75)
                elif d2[j] in v_words:
                    ff.append(1)
                else:
                    good = swn.senti_synsets(d2[j], 'n')
                    posscore = 0
                    for synst in good:
                        posscore = posscore + synst.pos_score()
                    ff.append(posscore)
            F.append(ff)
    D = []
    for k in range(len(F)):
        d = F[k]
        D.append(d)
    return D, p_D[: len(D)]


def IM_feat2(Pred):
    file = np.array(pd.read_csv("...\Dataset\\gssipcop_real.csv",
                       encoding='windows-1252', header=0, on_bad_lines="skip"))
    file = file[:, 2]
    file1 = np.array(pd.read_csv("...\Dataset\\gossipcop_fake.csv", header=None))
    file1 = file1[:, 2]
    Data = np.concatenate((file, file1), axis=0)

    F, p_D = [], []
    for i in range(len(Pred)):
        if Pred[i] == 1:
            d = Data[i]
            p_D.append([d])
            p_words, v_words = noun(d)
            d1 = d.replace("-", "").replace("(", "").replace(")", "").replace(",", "").replace('\x19', "")
            d2 = d1.split(" ")
            digits = "0123456789"
            ff = []
            for j in range(len(d2)):
                if d2[j] in digits:
                    ff.append(1)
                elif d2[j] in p_words:
                    ff.append(0.75)
                elif d2[j] in v_words:
                    ff.append(1)
                else:
                    good = swn.senti_synsets(d2[j], 'n')
                    posscore = 0
                    for synst in good:
                        posscore = posscore + synst.pos_score()
                    ff.append(posscore)
            F.append(ff)
    D = []
    for k in range(len(F)):
        d = F[k]
        D.append(d)
    return D, p_D[: len(D)]



