from Main import CNN_LSTM_FGSDO
from Comparative import CNN_LSTM_DOX, Deep_fake, Bi_lstm_RNN, CNN_LSTM_GSO, CNN_LSTM_GDSO, MVAN
import numpy as np
import IM_Word, IM_Feature
from Performance import DLSTM


def call_main(tr, Dataset):

    if Dataset == "Dataset1":
        Data = np.load("Dataset1_Vector.npy")                # Review Vector
        Label = np.load("Dataset1_Label.npy")                # Target

    else:
        Data = np.load("Dataset2_Vector.npy")                # Review Vector
        Label = np.load("Dataset2_Label.npy")                # Target

    ACC, SEN, SPE, TIME = [], [], [], []

    # Fake news detection
    Pred = CNN_LSTM_FGSDO.detect(Data, Label, tr, ACC, SEN, SPE, TIME)       # Proposed Model

    CNN_LSTM_GDSO.detect(Data, Label, tr, ACC, SEN, SPE, TIME)
    CNN_LSTM_GSO.detect(Data, Label, tr, ACC, SEN, SPE, TIME)
    Bi_lstm_RNN.detect(Data, Label, tr, ACC, SEN, SPE, TIME)
    CNN_LSTM_DOX.detect(Data, Label, tr, ACC, SEN, SPE, TIME)
    Deep_fake.detect(Data, Label, tr, ACC, SEN, SPE, TIME)
    MVAN.detect(Data, Label, tr, ACC, SEN, SPE, TIME)

    # Finding word impact measure
    if Dataset == "Dataset1":
        Im_word, Pred = IM_Word.IM_word1(Pred)
    else: Im_word, Pred = IM_Word.IM_word2(Pred)

    # Finding Feature word impact
    if Dataset == "Dataset1":
        Im_feat, F_data = IM_Feature.IM_feat1(Pred)
    else: Im_feat, F_data = IM_Feature.IM_feat2(Pred)

    # Impact Score Identification
    Is = Im_word + Im_feat

    ACC1, SEN1, SPE1 = [], [], []

    # Performance Analysis
    DLSTM.classify(Is, Label, tr, ACC1, SEN1, SPE1, 10, F_data, Data)
    DLSTM.classify(Is, Label, tr, ACC1, SEN1, SPE1, 20, F_data, Data)
    DLSTM.classify(Is, Label, tr, ACC1, SEN1, SPE1, 30, F_data, Data)
    DLSTM.classify(Is, Label, tr, ACC1, SEN1, SPE1, 40, F_data, Data)
    DLSTM.classify(Is, Label, tr, ACC1, SEN1, SPE1, 50, F_data, Data)

    return ACC, SEN, SPE, TIME,  ACC1, SEN1, SPE1


if __name__ == '__main__':
    Dataset = "Dataset1"            # Select Dataset 1 or 2
    ACC, SEN, SPE, TIME, ACC1, SEN1, SPE1 = call_main(0.9, Dataset)





