import spacy.cli
spacy.cli.download("en_core_web_md")
import spacy, numpy as np
from random import randint as r
import pandas as pd


def IM_word1(Pred):
    nlp = spacy.load("en_core_web_md")
    file = np.array(pd.read_csv("...\Dataset\\true news.csv",
                                 encoding='windows-1252', header=0, on_bad_lines="skip"))
    file = file[:, 1]
    file1 = np.array(pd.read_excel("...\Dataset\\Steni Jeyan.xls",
                                   header=None))
    file1 = file1[:, 1]
    Data = np.concatenate((file, file1), axis=0)

    F = []
    for i in range(len(Pred)):
        if Pred[i] == 1:
            d = Data[i]
            d1 = d
            doc = nlp(d1)
            s = []
            for d in doc:
                for d1 in doc:
                    s.append(d.similarity(d1))
            F.append(s)
    return F, Pred


def IM_word2(Pred):
    nlp = spacy.load("en_core_web_md")
    file = np.array(pd.read_csv("...\Dataset\\gossipcop_real.csv",
                                 encoding='windows-1252', header=0, on_bad_lines="skip"))
    file = file[:, 2]
    file1 = np.array(pd.read_csv("...\Dataset\\gossipcop_fake.csv",
                                   header=None))
    file1 = file1[:, 2]
    Data = np.concatenate((file, file1), axis=0)

    F = []
    for i in range(len(Pred)):
        if Pred[i] == 1:
            d = Data[i]
            d1 = d
            doc = nlp(d1)
            s = []
            for d in doc:
                for d1 in doc:
                    s.append(d.similarity(d1))
            F.append(s)
    return F, Pred