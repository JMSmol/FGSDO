from BertEmbeddings import BertEmbeddings
import numpy as np
import pandas as pd

# -------------------- Bert_vectorization for true_news data --------------------
file = pd.read_csv("...\Dataset\\true news.csv", encoding='windows-1252', header=0, on_bad_lines="skip")
file = file.iloc[:, 1].values

sentences = file
B_V = []

# VECTORIZATION
for i in range(len(sentences)):
    print(i)
    sentences2 = sentences[i].split(',')

    if len(sentences2[0]) > 1:
        sentences2 = sentences2[0]
    else:
        sentences2 = sentences2[1]

    bert_embedding = BertEmbeddings()
    result = bert_embedding(sentences2)

    for j in range(len(result)):
        try:
            if j == 0:
                full_v = result[j][1][0]
            else:
                full_v = full_v+result[j][1][0]
        except:
            full_v = np.zeros(768)
    # print(">>>==================", result[1])
    R1 = full_v
    B_V.append(R1)

B_V = np.array(B_V)
# np.save("Dataset1_Bert_vec.npy", B_V)

# -------------------- Bert_vectorization for Fake news data --------------------
file = pd.read_excel("...\Dataset\\Steni Jeyan.xls", header=None)
file = file.iloc[:, 1].values

sentences = file
B_V = []

# VECTORIZATION
for i in range(len(sentences)):
    print(i)
    sentences2 = sentences[i].split(',')

    if len(sentences2[0]) > 1:
        sentences2 = sentences2[0]
    else:
        sentences2 = sentences2[1]

    bert_embedding = BertEmbeddings()
    result = bert_embedding(sentences2)

    for j in range(len(result)):
        try:
            if j == 0:
                full_v = result[j][1][0]
            else:
                full_v = full_v+result[j][1][0]
        except:
            full_v = np.zeros(768)
    R1 = full_v
    B_V.append(R1)

B_V = np.array(B_V)
# np.save("Dataset1_Bert_vec1.npy", B_V)











