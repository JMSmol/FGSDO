from gensim.models import Word2Vec
import pandas as pd
import numpy as np

# -------------------- Word Vectorization for true news --------------------
file = pd.read_csv("...\Dataset1\\gossipcop_real.csv",
                   encoding='windows-1252', header=0, on_bad_lines="skip")
file = file.iloc[:, 2].values

word = file.astype("str")
ww = np.unique(word.flatten())
word2vec = Word2Vec(ww, min_count=2)

vv2 = []
# VECTORIZATION
for i in range(len(word)):
    v2 = []
    for j in range(len(word[i])):
        bbb = file[i][j]
        try:
            v1 = word2vec.wv[bbb]
            if len(v2) == 0:
                v2 = np.array(v1)
            else:
                v2 = v2+np.array(v1)
        except:
            if len(v2) == 0:
                v1 = np.random.random(100)
                v2 = np.array(v1)
            else:
                print(' ; ')
    vv2.append(v2.tolist())
vv = np.array(vv2)
# np.save("Dataset2_Word_vec.npy", vv)

from gensim.models import Word2Vec
import pandas as pd
import numpy as np


# -------------------- Word Vectorization for Fake news --------------------
file = pd.read_csv("...\Dataset1\\gossipcop_fake.csv",
                     header=None)
file = file.iloc[:, 2].values

word = file.astype("str")
ww = np.unique(word.flatten())
word2vec = Word2Vec(ww, min_count=2)

vv2 = []
# VECTORIZATION
for i in range(len(word)):
    v2 = []
    for j in range(len(word[i])):
        bbb = file[i][j]
        try:
            v1 = word2vec.wv[bbb]
            if len(v2) == 0:
                v2 = np.array(v1)
            else:
                v2 = v2+np.array(v1)
        except:
            if len(v2) == 0:
                v1 = np.random.random(100)
                v2 = np.array(v1)
            else:
                print(' ; ')
    vv2.append(v2.tolist())
vv = np.array(vv2)
# np.save("Dataset2_Word_vec1.npy", vv)


